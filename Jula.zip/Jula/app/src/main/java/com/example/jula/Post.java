package com.example.jula;

public class Post {
    String username,  text, link;

    public Post (String username, String text, String link) {

        this.username=username;
        this.text=text;
        this.link=link;
    }


}
